/* -------------------------------------------------
      _       _     ___                            
 __ _| |_ _ _(_)___/ __| __ __ _ _ _  _ _  ___ _ _ 
/ _` |  _| '_| / -_)__ \/ _/ _` | ' \| ' \/ -_) '_|
\__, |\__|_| |_\___|___/\__\__,_|_||_|_||_\___|_|  
|___/                                          
    
gtrieScanner: quick discovery of network motifs
Released under Artistic License 2.0
(see README and LICENSE)

Pedro Ribeiro - CRACS & INESC-TEC, DCC/FCUP

----------------------------------------------------
Error Utilities

Last Update: 11/02/2012
---------------------------------------------------- */

#ifndef _ERROR_
#define _ERROR_

#include "Graph.h"

#define EXIT_FAILURE 1

class Error {
 public:
  static void msg(const char *format, ...);
};

#endif
